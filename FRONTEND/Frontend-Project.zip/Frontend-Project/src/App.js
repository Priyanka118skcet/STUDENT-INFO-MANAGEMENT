import React, { Component } from "react";
import RoutingComp from'./routingComp';

export default function App() {
  return (
    <div>
      <RoutingComp />
    </div>
  );
}